import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0x000000);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 1000);
camera.position.set(4, 5, 11);
camera.lookAt(0, 0, 0);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.enablePan = false;
controls.minDistance = 5;
controls.maxDistance = 20;
controls.minPolarAngle = 0.5;
controls.maxPolarAngle = 1.5;
controls.autoRotate = false;
controls.target.set(1, 0, 1); // Set target to the computer's position
controls.update();

const groundGeometry = new THREE.PlaneGeometry(20, 20, 32, 32);
groundGeometry.rotateX(Math.PI / 2);
const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x555555, side: THREE.DoubleSide });
const groundMesh = new THREE.Mesh(groundGeometry, groundMaterial);
scene.add(groundMesh);

const spotLight = new THREE.SpotLight(0xffffff, 3, 100);
spotLight.position.set(0, 20, 0);
spotLight.angle = 0.2;
spotLight.penumbra = 0.5;
spotLight.castShadow = true;

const targetObject = new THREE.Object3D();
targetObject.position.set(1, 0, 2);
scene.add(targetObject);
spotLight.target = targetObject;
scene.add(spotLight);

const loader = new GLTFLoader().setPath('personal_computer/');
loader.load('scene.gltf', (gltf) => {
  const computerModel = gltf.scene;
  scene.add(computerModel);

  computerModel.position.set(1, -4.5, 1);
  computerModel.scale.set(5, 4, 8);

  const keyboardMaterial = computerModel.getObjectByName('keyboardMaterialName'); // Replace with the actual name
  if (keyboardMaterial) {
    keyboardMaterial.color.set(0xff00ff); // Set pink color
  }

  animate();
}, undefined, (error) => {
  console.error('Error loading model:', error);
});

const onWindowResize = () => {
  const newWidth = window.innerWidth;
  const newHeight = window.innerHeight;

  camera.aspect = newWidth / newHeight;
  camera.updateProjectionMatrix();

  renderer.setSize(newWidth, newHeight);
};

// Add an event listener to the window's resize event
window.addEventListener('resize', onWindowResize);

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}

animate();

//word navigations
const words = ["Web Development", "Frontend Development", "Web Designing"];
let wordIndex = 0;
let letterIndex = 0;

function displayNextLetter() {
  const letterContainer = document.getElementById("typing-text");
  const currentWord = words[wordIndex];
  
  if (letterIndex < currentWord.length) {
    letterContainer.textContent = currentWord.substring(0, letterIndex + 1);
    letterIndex++;
  } else {
    letterIndex = 0;
    wordIndex = (wordIndex + 1) % words.length;
  }
  
  setTimeout(displayNextLetter, 200); // Display the next letter after a delay
}

displayNextLetter(); // Start the loop

const container = document.querySelector(".image");
const image = document.querySelector("#profile");

// Track mouse movement within the container
container.addEventListener("mousemove", (e) => {
    const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
    const yAxis = (window.innerHeight / 2 - e.pageY) / 25;

    // Apply the tilt effect to the image
    image.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
});

// Reset the tilt effect when the mouse leaves the container
container.addEventListener("mouseleave", () => {
    image.style.transform = "rotateY(0deg) rotateX(0deg)";
});


/**
* PHP Email Form Validation - v3.8
* URL: https://bootstrapmade.com/php-email-form/
* Author: BootstrapMade.com
*/
(function () {
  "use strict";

  let forms = document.querySelectorAll('.php-email-form');

  forms.forEach( function(e) {
    e.addEventListener('submit', function(event) {
      event.preventDefault();

      let thisForm = this;

      let action = thisForm.getAttribute('action');
      let recaptcha = thisForm.getAttribute('data-recaptcha-site-key');
      
      if( ! action ) {
        displayError(thisForm, 'The form action property is not set!');
        return;
      }
      thisForm.querySelector('.loading').classList.add('d-block');
      thisForm.querySelector('.error-message').classList.remove('d-block');
      thisForm.querySelector('.sent-message').classList.remove('d-block');

      let formData = new FormData( thisForm );

      if ( recaptcha ) {
        if(typeof grecaptcha !== "undefined" ) {
          grecaptcha.ready(function() {
            try {
              grecaptcha.execute(recaptcha, {action: 'php_email_form_submit'})
              .then(token => {
                formData.set('recaptcha-response', token);
                php_email_form_submit(thisForm, action, formData);
              })
            } catch(error) {
              displayError(thisForm, error);
            }
          });
        } else {
          displayError(thisForm, 'The reCaptcha javascript API url is not loaded!')
        }
      } else {
        php_email_form_submit(thisForm, action, formData);
      }
    });
  });

  function php_email_form_submit(thisForm, action, formData) {
    fetch(action, {
      method: 'POST',
      body: formData,
      headers: {'X-Requested-With': 'XMLHttpRequest'}
    })
    .then(response => {
      if( response.ok ) {
        return response.text();
      } else {
        throw new Error(`${response.status} ${response.statusText} ${response.url}`); 
      }
    })
    .then(data => {
      thisForm.querySelector('.loading').classList.remove('d-block');
      if (data.trim() == 'OK') {
        thisForm.querySelector('.sent-message').classList.add('d-block');
        thisForm.reset(); 
      } else {
        throw new Error(data ? data : 'Form submission failed and no error message returned from: ' + action); 
      }
    })
    .catch((error) => {
      displayError(thisForm, error);
    });
  }

  function displayError(thisForm, error) {
    thisForm.querySelector('.loading').classList.remove('d-block');
    thisForm.querySelector('.error-message').innerHTML = error;
    thisForm.querySelector('.error-message').classList.add('d-block');
  }

})();

document.addEventListener("DOMContentLoaded", function() {
    const sections = document.querySelectorAll("#home, #me, #services, #resume, #contact, #footer");

    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1
    });

    sections.forEach(section => {
      observer.observe(section);
    });
  });

